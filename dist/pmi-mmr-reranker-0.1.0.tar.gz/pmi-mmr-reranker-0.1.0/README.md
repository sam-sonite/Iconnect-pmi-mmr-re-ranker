# MS MARCO FAISS Database

This workspace builds a local FAISS vector database from:

- `/Users/indrajitkar/Downloads/MSMarco/train.csv`

It embeds each row with a dependency-light local hash encoder so the index can be
built fully offline and without `pandas`. Each row becomes a combined retrieval
document containing:

- `query`
- `answers`
- `finalpassage`

## Build

```bash
python3 build_faiss_db.py
```

Artifacts are written to `faiss_db/`:

- `index.faiss`
- `metadata.jsonl`
- `config.json`

## Search

```bash
python3 search_faiss_db.py --query "why do children get aggressive" --top-k 5
```
